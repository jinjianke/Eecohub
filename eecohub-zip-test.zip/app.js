const status = document.querySelector("#js-status");
const deployTime = document.querySelector("#deploy-time");
const currentUrl = document.querySelector("#current-url");
const button = document.querySelector("#test-button");
const message = document.querySelector("#message");

status.textContent = "\u72ec\u7acb\u811a\u672c\u52a0\u8f7d\u6210\u529f";
deployTime.textContent = new Intl.DateTimeFormat("zh-CN", {
  year: "numeric", month: "2-digit", day: "2-digit",
  hour: "2-digit", minute: "2-digit", second: "2-digit"
}).format(new Date());
currentUrl.textContent = window.location.href;

button.addEventListener("click", () => {
  message.textContent = "JavaScript \u8fd0\u884c\u6b63\u5e38\uff0cZIP \u591a\u6587\u4ef6\u90e8\u7f72\u6d4b\u8bd5\u901a\u8fc7\uff01";
  message.classList.add("success");
  button.textContent = "\u6d4b\u8bd5\u901a\u8fc7 \u2713";
});
